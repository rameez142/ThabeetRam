﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MOI.AssetManagement.ClientApp.src.app.components.map.services
{
    public class QryString
    {
    }
}
