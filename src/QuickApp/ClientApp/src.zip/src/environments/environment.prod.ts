// ====================================================

// Email: support@ebenmonney.com
// ====================================================

export const environment = {
  production: true,
  baseUrl: null, //Change this to the address of your backend API if different from frontend address
  loginUrl: "/Login",
  mapbox: {
    accessToken: 'pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4M29iazA2Z2gycXA4N2pmbDZmangifQ.-g_vE53SD2WrJ6tFX7QHmA'
  }
};
